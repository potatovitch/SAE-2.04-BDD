class Colonne{
    public static void main(String[] args){
        String res = "";
        int len = Integer.parseInt(args[0]);
        for(int i = 0; i < len; i ++){
            res += "n"+(i+1);
            if(args.length > 1){
                res += " " + args[1];
            }
            res += ",";
        }
        res = res.substring(0, res.length()-1);
        System.out.println(res);
    }
}
